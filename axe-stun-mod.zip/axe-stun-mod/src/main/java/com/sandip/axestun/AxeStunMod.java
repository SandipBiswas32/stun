package com.sandip.axestun;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

import java.util.ArrayList;
import java.util.List;

/**
 * Axe se blocking player ka shield disable hote hi mod KHUD doosra hit
 * maar deta hai (auto double-click) = shield stun.
 */
public class AxeStunMod implements ModInitializer {
    public static final String MOD_ID = "axestun";

    private record Pending(ServerPlayerEntity attacker, ServerPlayerEntity target, ItemStack shield) {}

    private final List<Pending> pending = new ArrayList<>();
    private boolean autoHitting = false;

    @Override
    public void onInitialize() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (autoHitting || world.isClient() || hand != Hand.MAIN_HAND) return ActionResult.PASS;
            if (!(player instanceof ServerPlayerEntity attacker)) return ActionResult.PASS;
            if (!(entity instanceof ServerPlayerEntity target)) return ActionResult.PASS;
            if (!attacker.getMainHandStack().isIn(ItemTags.AXES)) return ActionResult.PASS;
            if (!target.isBlocking()) return ActionResult.PASS;

            pending.add(new Pending(attacker, target, target.getActiveItem().copy()));
            return ActionResult.PASS;
        });

        // Isi tick ke end me: shield disable hua? to doosra hit auto maaro
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (pending.isEmpty()) return;
            List<Pending> work = new ArrayList<>(pending);
            pending.clear();

            for (Pending p : work) {
                ServerPlayerEntity a = p.attacker();
                ServerPlayerEntity t = p.target();
                if (a.isRemoved() || t.isRemoved() || !t.isAlive()) continue;
                if (!a.getMainHandStack().isIn(ItemTags.AXES)) continue;
                if (a.squaredDistanceTo(t) > 36.0) continue;

                if (t.getItemCooldownManager().isCoolingDown(p.shield())) {
                    autoHitting = true;
                    try {
                        a.swingHand(Hand.MAIN_HAND);
                        a.attack(t);
                    } finally {
                        autoHitting = false;
                    }
                }
            }
        });
    }
}
